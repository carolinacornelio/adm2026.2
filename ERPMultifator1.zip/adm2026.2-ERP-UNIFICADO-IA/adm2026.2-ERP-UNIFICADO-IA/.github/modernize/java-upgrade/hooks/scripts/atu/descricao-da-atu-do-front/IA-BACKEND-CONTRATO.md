# Contrato para integração do Assistente IA

O front-end foi preparado para o Spring Boot assumir a análise real.

## Endpoint principal

`POST /api/ia/perguntar`

Request inicial:

```json
{
  "pergunta": "Quais produtos estão vendendo menos?"
}
```

O backend deve:

1. Identificar a intenção/pergunta.
2. Identificar quais dados são necessários.
3. Consultar somente dados da `empresa_id` do usuário autenticado.
4. Aplicar as regras de negócio e cálculos necessários.
5. Enviar para o provedor/modelo de IA somente o contexto necessário.
6. Retornar uma resposta estruturada.

Exemplo de resposta:

```json
{
  "resposta": "Os dados indicam queda de vendas no produto X..."
}
```

## Faturamento

`GET /api/dashboard/faturamento?mesReferencia=2026-09`

Resposta esperada:

```json
{
  "mesAtual": "2026-09",
  "faturamentoAtual": 38700.00,
  "mesAnterior": "2026-08",
  "faturamentoAnterior": 32500.00,
  "variacaoPercentual": 19.08
}
```

O faturamento deve ser calculado no backend a partir das vendas da empresa autenticada.

## Categorias

`GET /api/categorias`

O produto deve usar `categoriaId`, alinhado à tabela `categorias` e à coluna `produtos.categoria_id` do `Script.sql`.

## Segurança

- Não colocar chave de API do provedor de IA no JavaScript.
- Não confiar no plano informado pelo navegador.
- O Spring Security deve obter a empresa do usuário autenticado.
- Todas as consultas devem filtrar por `empresa_id`.
- O backend deve verificar o plano antes de liberar:
  - categorias/filtros avançados;
  - faturamento;
  - `/api/ia/perguntar`.
- Nunca enviar CPF, senha, hash de senha ou outros dados desnecessários ao modelo.

## Planos

- `BASE`: recursos atuais.
- `PLUS`: BASE + categorias/filtros + dashboard de faturamento + Assistente IA.
- `PREMIUM`: tudo do PLUS.
