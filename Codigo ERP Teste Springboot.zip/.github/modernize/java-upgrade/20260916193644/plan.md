# Upgrade Plan: adm2026 (20260916193644)

- **Generated**: 2026-09-16
- **HEAD Branch**: N/A
- **HEAD Commit ID**: N/A

## Available Tools

**JDKs**
- JDK 21.0.12.1: `C:\Program Files\Java\jdk-21.0.12.1\bin` (current project JDK, used for baseline)
- JDK 25: **<TO_BE_INSTALLED>** (required for upgrade and final validation)

**Build Tools**
- Maven 3.9.16: `C:\Users\aryel\Downloads\apache-maven-3.9.16-bin\apache-maven-3.9.16\bin`

> Version control is unavailable because this workspace is not a Git repository; changes will remain uncommitted.

## Guidelines

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: N/A (workspace is not version-controlled)
- Run tests before and after the upgrade: true

## Upgrade Goals

- Upgrade Java runtime and compiler target from 21 to Java 25 LTS.

## Technology Stack

| Technology/Dependency | Current | Min Compatible Version | Why Incompatible |
| --------------------- | ------- | ---------------------- | ---------------- |
| Java | 21 | 25 | User requested latest LTS |
| Spring Boot | 3.5.5 | 3.5.5 | Compatible with Java 25; no upgrade required |
| Maven | 3.9.16 | 3.9+ | Already compatible with Java 25 |
| maven-compiler-plugin | 3.11.0 | 3.11.0 | Existing plugin delegates compilation to the selected JDK |
| PostgreSQL JDBC | 42.7.3 | 42.7.3 | No Java 25 incompatibility identified |

## Derived Upgrades

- Install JDK 25 because Java 25 compilation and runtime validation require a matching JDK.
- Update Maven compiler source and target values from 21 to 25 so production and test code compile for the target runtime.
- Keep Spring Boot 3.5.5 and Maven 3.9.16 unchanged because they already satisfy the target compatibility requirements.

## Impact Analysis

### Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
|------|------------|---------|--------|--------|--------|
| `pom.xml` | `maven.compiler.source` | 21 | upgrade | 25 | Set Java source compatibility to the requested LTS |
| `pom.xml` | `maven.compiler.target` | 21 | upgrade | 25 | Emit Java 25-compatible bytecode |
| `pom.xml` | `maven-compiler-plugin` configuration | `<source>21</source>`, `<target>21</target>` | upgrade | `<source>25</source>`, `<target>25</target>` | Align explicit plugin configuration with project properties |

### Source Code Changes

| File | Location | Current | Required Change | Reason |
|------|----------|---------|----------------|--------|
| None | N/A | No Java 25-incompatible APIs identified from the project structure | None | Java 21 source is expected to remain source-compatible on Java 25 |

### Configuration Changes

| File | Property/Setting | Current | Required Change | Reason |
|------|------------------|---------|----------------|--------|
| None | N/A | No runtime configuration pins Java 21 | None | No configuration update is required |

### CI/CD Changes

| File | Location | Current | Required Change |
|------|----------|---------|----------------|
| None detected | N/A | No CI/CD file was identified in the workspace listing | None |

### Risks & Warnings

- **JDK 25 availability**: The machine currently exposes only JDK 21. **Mitigation**: Install JDK 25 before changing the compiler target and run a clean compile and full test suite with it.
- **Runtime compatibility beyond compilation**: Java 25 can expose reflective or JVM-option incompatibilities not visible at compile time. **Mitigation**: Run the complete Maven test suite and package the application using JDK 25.
- **No version control**: The workspace is not a Git repository. **Mitigation**: Preserve the working tree and record all changes in progress and summary artifacts.

## Upgrade Steps

- Step 1: Setup Environment
  - **Rationale**: Install and verify JDK 25 before applying target-version changes.
  - **Changes to Make**: Install JDK 25; retain Maven 3.9.16.
  - **Verification**: List installed JDKs; expected JDK 25 is available.

- Step 2: Setup Baseline
  - **Rationale**: Establish the current Java 21 compile and test baseline before modification.
  - **Changes to Make**: No project changes.
  - **Verification**: `mvn clean compile test-compile -q && mvn clean test -q` with JDK 21; expected baseline success.

- Step 3: Upgrade Java compiler target
  - **Rationale**: Apply all required project configuration changes for Java 25.
  - **Changes to Make**: Apply Dependency Changes above in `pom.xml`.
  - **Verification**: `mvn clean test-compile -q` with JDK 25; expected successful main and test compilation.

- Step 4: Final Validation
  - **Rationale**: Confirm the target runtime, packaging, and complete test suite.
  - **Changes to Make**: Resolve any Java 25 build or test failures and remove temporary workarounds.
  - **Verification**: `mvn clean test -q` and `mvn package -DskipTests` with JDK 25; expected 100% tests pass and package succeeds.
