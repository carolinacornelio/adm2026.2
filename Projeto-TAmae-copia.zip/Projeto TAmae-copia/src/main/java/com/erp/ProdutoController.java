package com.erp;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import java.util.*;

/** CRUD REST de produtos. O empresaId sempre vem da sessão, nunca do JSON. */
@RestController
@RequestMapping("/api/produtos")
public class ProdutoController {
    private final JdbcTemplate db; private final CurrentUser user;
    public ProdutoController(JdbcTemplate db, CurrentUser user) { this.db=db; this.user=user; }
    /** Lista somente produtos ativos pertencentes à empresa do usuário. */
    @GetMapping List<Map<String,Object>> listar(@RequestHeader("Authorization") String a) { return db.queryForList("""
        SELECT p.id,p.nome,p.codigo,p.descricao,p.preco AS "precoVenda",p.preco AS "precoCompra",
        COALESCE(e.quantidade,0) AS "quantidadeEstoque",COALESCE(e.estoque_minimo,0) AS "estoqueMinimo",
        COALESCE(c.nome,'Sem Categoria') AS categoria FROM produtos p
        LEFT JOIN estoque e ON e.produto_id=p.id AND e.empresa_id=p.empresa_id
        LEFT JOIN categorias c ON c.id=p.categoria_id AND c.empresa_id=p.empresa_id
        WHERE p.empresa_id=? AND p.ativo=true ORDER BY p.id""", user.empresa(a)); }
    @GetMapping("/{id}") Map<String,Object> buscar(@PathVariable int id,@RequestHeader("Authorization") String a) { List<Map<String,Object>> x=db.queryForList("SELECT p.id,p.nome,p.codigo,p.descricao,p.preco AS \"precoVenda\",p.preco AS \"precoCompra\",COALESCE(e.quantidade,0) AS \"quantidadeEstoque\",COALESCE(e.estoque_minimo,0) AS \"estoqueMinimo\" FROM produtos p LEFT JOIN estoque e ON e.produto_id=p.id AND e.empresa_id=p.empresa_id WHERE p.id=? AND p.empresa_id=? AND p.ativo=true",id,user.empresa(a)); if(x.isEmpty()) throw new IllegalArgumentException("Produto não encontrado."); return x.get(0); }
    /** Cria o produto e sua linha inicial de estoque na mesma transação. */
    @PostMapping @Transactional Map<String,Object> criar(@RequestBody Map<String,Object> d,@RequestHeader("Authorization") String a) { int e=user.empresa(a); String nome=AuthService.texto(d,"nome"); double preco=numero(d,"precoVenda"); String codigo=String.valueOf(d.getOrDefault("codigo","")); if(codigo.isBlank())codigo="COD-"+System.currentTimeMillis(); Number id=db.queryForObject("INSERT INTO produtos(empresa_id,nome,codigo,preco,descricao,ativo) VALUES(?,?,?,?,?,true) RETURNING id",Number.class,e,nome,codigo,preco,d.getOrDefault("descricao","")); db.update("INSERT INTO estoque(empresa_id,produto_id,quantidade,estoque_minimo) VALUES(?,?,0,?)",e,id,intNumero(d,"estoqueMinimo")); return buscar(id.intValue(),a); }
    @PutMapping("/{id}") Map<String,Object> atualizar(@PathVariable int id,@RequestBody Map<String,Object> d,@RequestHeader("Authorization") String a) { int e=user.empresa(a); String codigo=String.valueOf(d.getOrDefault("codigo","")); if(codigo.isBlank())codigo="COD-"+id; int n=db.update("UPDATE produtos SET nome=?,codigo=?,preco=?,descricao=? WHERE id=? AND empresa_id=? AND ativo=true",AuthService.texto(d,"nome"),codigo,numero(d,"precoVenda"),d.getOrDefault("descricao",""),id,e); if(n==0) throw new IllegalArgumentException("Produto não encontrado."); db.update("UPDATE estoque SET estoque_minimo=? WHERE produto_id=? AND empresa_id=?",intNumero(d,"estoqueMinimo"),id,e); return buscar(id,a); }
    /** Exclusão lógica: preserva o histórico e oculta o produto das listagens. */
    @DeleteMapping("/{id}") void remover(@PathVariable int id,@RequestHeader("Authorization") String a) { if(db.update("UPDATE produtos SET ativo=false WHERE id=? AND empresa_id=?",id,user.empresa(a))==0) throw new IllegalArgumentException("Produto não encontrado."); }
    static double numero(Map<String,Object>d,String k){return Double.parseDouble(String.valueOf(d.getOrDefault(k,0)));} static int intNumero(Map<String,Object>d,String k){return (int)numero(d,k);}
}
